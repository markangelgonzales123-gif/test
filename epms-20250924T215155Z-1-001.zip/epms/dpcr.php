<?php
// Set page title
$page_title = "Department Performance Commitment and Review - EPMS";

// Include header
include_once('includes/header.php');

// Check if user is logged in and has appropriate role
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] != 'department_head' && $_SESSION['user_role'] != 'admin')) {
    header("Location: access_denied.php");
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "epms_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user info
$user_id = $_SESSION['user_id'];
$department_id = $_SESSION['user_department_id'];

// Get department info
$dept_query = "SELECT d.*, u.name as head_name 
               FROM departments d 
               LEFT JOIN users u ON d.head_id = u.id
               WHERE d.id = ?";
$stmt = $conn->prepare($dept_query);
$stmt->bind_param("i", $department_id);
$stmt->execute();
$dept_result = $stmt->get_result();
$department = ($dept_result->num_rows > 0) ? $dept_result->fetch_assoc() : null;

// Get action from URL
$action = isset($_GET['action']) ? $_GET['action'] : 'view';
$record_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Function to generate periods (quarters)
function generatePeriods() {
    $current_year = date('Y');
    $periods = [];
    
    for ($i = 0; $i < 2; $i++) {
        $year = $current_year + $i;
        $periods[] = "Q1 $year";
        $periods[] = "Q2 $year";
        $periods[] = "Q3 $year";
        $periods[] = "Q4 $year";
    }
    
    return $periods;
}

// Get computation types from database
function getComputationTypes() {
    global $conn;
    $query = "SELECT setting_value, description FROM system_settings WHERE setting_key = 'dpcr_computation_type'";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        $setting = $result->fetch_assoc();
        return [
            'Type1' => 'Strategic (45%) and Core (55%)',
            'Type2' => 'Strategic (45%), Core (45%), and Support (10%)'
        ];
    }
    
    return [
        'Type1' => 'Strategic (45%) and Core (55%)',
        'Type2' => 'Strategic (45%), Core (45%), and Support (10%)'
    ];
}

// Handle form submission for new DPCR
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_dpcr'])) {
    $period = $_POST['period'];
    $status = isset($_POST['submit_now']) ? 'Pending' : 'Draft';
    $date_submitted = isset($_POST['submit_now']) ? date('Y-m-d H:i:s') : null;
    $computation_type = $_POST['computation_type'] ?? 'Type1';
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Insert or update record
        if ($record_id > 0) {
            // Update existing record
            $update_record = "UPDATE records SET 
                             period = ?, 
                             status = ?,
                             date_submitted = ?,
                             computation_type = ?
                             WHERE id = ? AND user_id = ?";
            $stmt = $conn->prepare($update_record);
            $stmt->bind_param("ssssii", $period, $status, $date_submitted, $computation_type, $record_id, $user_id);
            $stmt->execute();
            
            // Delete existing entries to replace with new ones
            $delete_entries = "DELETE FROM dpcr_entries WHERE record_id = ?";
            $stmt = $conn->prepare($delete_entries);
            $stmt->bind_param("i", $record_id);
            $stmt->execute();
        } else {
            // Insert new record
            $insert_record = "INSERT INTO records (user_id, form_type, period, status, date_submitted, computation_type) 
                             VALUES (?, 'DPCR', ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_record);
            $stmt->bind_param("issss", $user_id, $period, $status, $date_submitted, $computation_type);
            $stmt->execute();
            $record_id = $conn->insert_id;
        }
        
        // Process strategic entries (45%)
        if (isset($_POST['strategic_major_output']) && is_array($_POST['strategic_major_output'])) {
            $count = count($_POST['strategic_major_output']);
            
            for ($i = 0; $i < $count; $i++) {
                if (!empty($_POST['strategic_major_output'][$i])) {
                    $insert_entry = "INSERT INTO dpcr_entries 
                                    (record_id, major_output, success_indicators, budget, accountable, category) 
                                    VALUES (?, ?, ?, ?, ?, 'Strategic')";
                    $stmt = $conn->prepare($insert_entry);
                    $major_output = $_POST['strategic_major_output'][$i];
                    $success_indicators = $_POST['strategic_success_indicators'][$i];
                    $budget = !empty($_POST['strategic_budget'][$i]) ? $_POST['strategic_budget'][$i] : null;
                    $accountable = $_POST['strategic_accountable'][$i];
                    
                    $stmt->bind_param("issds", $record_id, $major_output, $success_indicators, $budget, $accountable);
                    $stmt->execute();
                }
            }
        }
        
        // Process core entries (55%)
        if (isset($_POST['core_major_output']) && is_array($_POST['core_major_output'])) {
            $count = count($_POST['core_major_output']);
            
            for ($i = 0; $i < $count; $i++) {
                if (!empty($_POST['core_major_output'][$i])) {
                    $insert_entry = "INSERT INTO dpcr_entries 
                                    (record_id, major_output, success_indicators, budget, accountable, category) 
                                    VALUES (?, ?, ?, ?, ?, 'Core')";
                    $stmt = $conn->prepare($insert_entry);
                    $major_output = $_POST['core_major_output'][$i];
                    $success_indicators = $_POST['core_success_indicators'][$i];
                    $budget = !empty($_POST['core_budget'][$i]) ? $_POST['core_budget'][$i] : null;
                    $accountable = $_POST['core_accountable'][$i];
                    
                    $stmt->bind_param("issds", $record_id, $major_output, $success_indicators, $budget, $accountable);
                    $stmt->execute();
                }
            }
        }
        
        // Process support entries (10%) - Only for Type2
        if ($computation_type === 'Type2' && isset($_POST['support_major_output']) && is_array($_POST['support_major_output'])) {
            $count = count($_POST['support_major_output']);
            
            for ($i = 0; $i < $count; $i++) {
                if (!empty($_POST['support_major_output'][$i])) {
                    $insert_entry = "INSERT INTO dpcr_entries 
                                    (record_id, major_output, success_indicators, budget, accountable, category) 
                                    VALUES (?, ?, ?, ?, ?, 'Support')";
                    $stmt = $conn->prepare($insert_entry);
                    $major_output = $_POST['support_major_output'][$i];
                    $success_indicators = $_POST['support_success_indicators'][$i];
                    $budget = !empty($_POST['support_budget'][$i]) ? $_POST['support_budget'][$i] : null;
                    $accountable = $_POST['support_accountable'][$i];
                    
                    $stmt->bind_param("issds", $record_id, $major_output, $success_indicators, $budget, $accountable);
                    $stmt->execute();
                }
            }
        }
        
        // Commit transaction
        $conn->commit();
        
        // Set success message
        $message = $status === 'Pending' ? 'DPCR submitted successfully!' : 'DPCR saved as draft!';
        $_SESSION['success_message'] = $message;
        
        // Redirect to records page or view page
        if ($status === 'Pending') {
            header("Location: records.php");
        } else {
            header("Location: dpcr.php?action=edit&id=" . $record_id);
        }
        exit();
        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        $_SESSION['error_message'] = "Error: " . $e->getMessage();
    }
}

// Load existing DPCR data if editing
$dpcr_data = [];
$strategic_entries = [];
$core_entries = [];
$support_entries = [];

if ($record_id > 0 && ($action === 'edit' || $action === 'view')) {
    // Get record data
    $record_query = "SELECT * FROM records WHERE id = ? AND form_type = 'DPCR'";
    $stmt = $conn->prepare($record_query);
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $record_result = $stmt->get_result();
    
    if ($record_result->num_rows === 0) {
        $_SESSION['error_message'] = "DPCR record not found!";
        header("Location: records.php");
        exit();
    }
    
    $dpcr_data = $record_result->fetch_assoc();
    
    // Check if user has permission to edit this record
    if ($action === 'edit' && $dpcr_data['user_id'] != $user_id && $_SESSION['user_role'] !== 'admin') {
        $_SESSION['error_message'] = "You don't have permission to edit this DPCR!";
        header("Location: records.php");
        exit();
    }
    
    // Check if record is editable (must be in Draft status)
    if ($action === 'edit' && $dpcr_data['status'] !== 'Draft') {
        $_SESSION['error_message'] = "Only drafts can be edited!";
        header("Location: dpcr.php?action=view&id=" . $record_id);
        exit();
    }
    
    // Get DPCR entries
    $entries_query = "SELECT * FROM dpcr_entries WHERE record_id = ? ORDER BY id ASC";
    $stmt = $conn->prepare($entries_query);
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $entries_result = $stmt->get_result();
    
    // Organize entries by category
    while ($entry = $entries_result->fetch_assoc()) {
        if ($entry['category'] === 'Strategic') {
            $strategic_entries[] = $entry;
        } elseif ($entry['category'] === 'Core') {
            $core_entries[] = $entry;
        } elseif ($entry['category'] === 'Support') {
            $support_entries[] = $entry;
        }
    }
}

// Ensure we have at least one empty entry for each category when creating/editing
if ($action === 'new' || $action === 'edit') {
    if (empty($strategic_entries)) {
        $strategic_entries[] = ['major_output' => '', 'success_indicators' => '', 'budget' => '', 'accountable' => ''];
    }
    if (empty($core_entries)) {
        $core_entries[] = ['major_output' => '', 'success_indicators' => '', 'budget' => '', 'accountable' => ''];
    }
}

// Check if we have success/error messages
$success_message = isset($_SESSION['success_message']) ? $_SESSION['success_message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';

// Clear session messages
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);
?>

<!-- DPCR Content -->
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">
            <?php 
            if ($action === 'new') echo 'Create New DPCR';
            else if ($action === 'edit') echo 'Edit DPCR';
            else echo 'View DPCR';
            ?>
        </h1>
        <div>
            <a href="records.php" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back to Records
            </a>
            <?php if ($action === 'view' && isset($dpcr_data['id'])): ?>
                <a href="print_record.php?id=<?php echo $dpcr_data['id']; ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-printer"></i> Print
                </a>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Department Performance Commitment and Review (DPCR)</h5>
        </div>
        <div class="card-body">
            <!-- DPCR Form -->
            <form method="post" action="" id="dpcrForm">
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="department" class="form-label">Department</label>
                            <input type="text" class="form-control" id="department" value="<?php echo htmlspecialchars($department['name'] ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="head" class="form-label">Department Head</label>
                            <input type="text" class="form-control" id="head" value="<?php echo htmlspecialchars($department['head_name'] ?? ''); ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="mb-3">
                            <label for="period" class="form-label">Period</label>
                            <?php if ($action === 'view'): ?>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($dpcr_data['period'] ?? ''); ?>" readonly>
                            <?php else: ?>
                                <select class="form-select" id="period" name="period" required>
                                    <option value="">-- Select Period --</option>
                                    <?php foreach (generatePeriods() as $period): ?>
                                        <option value="<?php echo $period; ?>" <?php echo (isset($dpcr_data['period']) && $dpcr_data['period'] === $period) ? 'selected' : ''; ?>>
                                            <?php echo $period; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="computation_type" class="form-label">Computation Type</label>
                    <select class="form-select" name="computation_type" id="computation_type" required>
                        <?php
                        $computation_types = getComputationTypes();
                        foreach ($computation_types as $type => $description) {
                            $selected = ($dpcr_data && $dpcr_data['computation_type'] === $type) ? 'selected' : '';
                            echo "<option value=\"$type\" $selected>$description</option>";
                        }
                        ?>
                    </select>
                    <div class="form-text">
                        Type 1: Strategic (45%) and Core (55%)<br>
                        Type 2: Strategic (45%), Core (45%), and Support (10%)
                    </div>
                </div>
                
                <div class="mb-3 text-center">
                    <h5>Department Performance Commitment and Review</h5>
                    <p class="mb-0">Department: <?php echo htmlspecialchars($department['name'] ?? 'Unknown Department'); ?></p>
                    <p>Head: <?php echo htmlspecialchars($department['head_name'] ?? 'Unknown'); ?></p>
                </div>

                <!-- Strategic Functions (45%) -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Strategic Functions (45%)</h5>
                        <?php if ($action === 'new' || $action === 'edit'): ?>
                        <button type="button" class="btn btn-sm btn-outline-primary" id="addStrategicRow">
                            <i class="bi bi-plus-circle"></i> Add Row
                        </button>
                        <?php endif; ?>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th width="30%">Major Final Output</th>
                                    <th width="30%">Success Indicators</th>
                                    <th width="15%">Budget</th>
                                    <th width="20%">Accountable Units</th>
                                    <?php if ($action === 'new' || $action === 'edit'): ?>
                                    <th width="5%">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody id="strategicTableBody">
                                <?php if ($action === 'view' && empty($strategic_entries)): ?>
                                <tr>
                                    <td colspan="4" class="text-center">No strategic outputs defined</td>
                                </tr>
                                <?php else: ?>
                                    <?php foreach ($strategic_entries as $index => $entry): ?>
                                    <tr class="strategic-row">
                                        <td>
                                            <?php if ($action === 'view'): ?>
                                                <?php echo nl2br(htmlspecialchars($entry['major_output'])); ?>
                                            <?php else: ?>
                                                <textarea class="form-control" name="strategic_major_output[]" rows="3" required><?php echo htmlspecialchars($entry['major_output']); ?></textarea>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($action === 'view'): ?>
                                                <?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?>
                                            <?php else: ?>
                                                <textarea class="form-control" name="strategic_success_indicators[]" rows="3" required><?php echo htmlspecialchars($entry['success_indicators']); ?></textarea>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($action === 'view'): ?>
                                                <?php echo htmlspecialchars($entry['budget'] ? number_format($entry['budget'], 2) : 'N/A'); ?>
                                            <?php else: ?>
                                                <input type="number" class="form-control" name="strategic_budget[]" step="0.01" value="<?php echo htmlspecialchars($entry['budget'] ?? ''); ?>">
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($action === 'view'): ?>
                                                <?php echo htmlspecialchars($entry['accountable']); ?>
                                            <?php else: ?>
                                                <input type="text" class="form-control" name="strategic_accountable[]" value="<?php echo htmlspecialchars($entry['accountable'] ?? ''); ?>" required>
                                            <?php endif; ?>
                                        </td>
                                        <?php if ($action === 'new' || $action === 'edit'): ?>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-danger remove-row">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </td>
                                        <?php endif; ?>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Core Functions Section (55% for Type1, 45% for Type2) -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0">Core Functions
                            <span id="core_weight" class="float-end">
                                (55%)
                            </span>
                        </h6>
                    </div>
                    <div class="card-body">
                        <div id="core_functions">
                            <?php
                            // Display existing core entries
                            if (!empty($core_entries)) {
                                foreach ($core_entries as $index => $entry) {
                                    ?>
                                    <div class="row mb-3 core-entry">
                                        <div class="col-md-4">
                                            <label>Major Final Output</label>
                                            <textarea class="form-control" name="core_major_output[]" rows="3" required><?php echo htmlspecialchars($entry['major_output']); ?></textarea>
                                        </div>
                                        <div class="col-md-3">
                                            <label>Success Indicators</label>
                                            <textarea class="form-control" name="core_success_indicators[]" rows="3" required><?php echo htmlspecialchars($entry['success_indicators']); ?></textarea>
                                        </div>
                                        <div class="col-md-2">
                                            <label>Budget</label>
                                            <input type="number" class="form-control" name="core_budget[]" value="<?php echo htmlspecialchars($entry['budget']); ?>" step="0.01" min="0">
                                        </div>
                                        <div class="col-md-2">
                                            <label>Accountable Person/Office</label>
                                            <input type="text" class="form-control" name="core_accountable[]" value="<?php echo htmlspecialchars($entry['accountable']); ?>">
                                        </div>
                                        <div class="col-md-1">
                                            <label>&nbsp;</label>
                                            <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                                        </div>
                                    </div>
                                    <?php
                                }
                            } else {
                                // Add empty row for new record
                                ?>
                                <div class="row mb-3 core-entry">
                                    <div class="col-md-4">
                                        <label>Major Final Output</label>
                                        <textarea class="form-control" name="core_major_output[]" rows="3" required></textarea>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Success Indicators</label>
                                        <textarea class="form-control" name="core_success_indicators[]" rows="3" required></textarea>
                                    </div>
                                    <div class="col-md-2">
                                        <label>Budget</label>
                                        <input type="number" class="form-control" name="core_budget[]" step="0.01" min="0">
                                    </div>
                                    <div class="col-md-2">
                                        <label>Accountable Person/Office</label>
                                        <input type="text" class="form-control" name="core_accountable[]">
                                    </div>
                                    <div class="col-md-1">
                                        <label>&nbsp;</label>
                                        <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-success" id="add_core_entry">
                            <i class="bi bi-plus-circle"></i> Add Core Function
                        </button>
                    </div>
                </div>
                
                <!-- Support Functions Section (10%) - Only for Type2 -->
                <div class="card mb-4" id="support_functions_container" style="display: none;">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">Support Functions
                            <span class="float-end">
                                (10%)
                            </span>
                        </h6>
                    </div>
                    <div class="card-body">
                        <div id="support_functions">
                            <?php
                            // Display existing support entries if any
                            if (!empty($support_entries)) {
                                foreach ($support_entries as $index => $entry) {
                                    ?>
                                    <div class="row mb-3 support-entry">
                                        <div class="col-md-4">
                                            <label>Major Final Output</label>
                                            <textarea class="form-control" name="support_major_output[]" rows="3"><?php echo htmlspecialchars($entry['major_output']); ?></textarea>
                                        </div>
                                        <div class="col-md-3">
                                            <label>Success Indicators</label>
                                            <textarea class="form-control" name="support_success_indicators[]" rows="3"><?php echo htmlspecialchars($entry['success_indicators']); ?></textarea>
                                        </div>
                                        <div class="col-md-2">
                                            <label>Budget</label>
                                            <input type="number" class="form-control" name="support_budget[]" value="<?php echo htmlspecialchars($entry['budget']); ?>" step="0.01" min="0">
                                        </div>
                                        <div class="col-md-2">
                                            <label>Accountable Person/Office</label>
                                            <input type="text" class="form-control" name="support_accountable[]" value="<?php echo htmlspecialchars($entry['accountable']); ?>">
                                        </div>
                                        <div class="col-md-1">
                                            <label>&nbsp;</label>
                                            <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                                        </div>
                                    </div>
                                    <?php
                                }
                            } else {
                                // Add empty row for new record
                                ?>
                                <div class="row mb-3 support-entry">
                                    <div class="col-md-4">
                                        <label>Major Final Output</label>
                                        <textarea class="form-control" name="support_major_output[]" rows="3"></textarea>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Success Indicators</label>
                                        <textarea class="form-control" name="support_success_indicators[]" rows="3"></textarea>
                                    </div>
                                    <div class="col-md-2">
                                        <label>Budget</label>
                                        <input type="number" class="form-control" name="support_budget[]" step="0.01" min="0">
                                    </div>
                                    <div class="col-md-2">
                                        <label>Accountable Person/Office</label>
                                        <input type="text" class="form-control" name="support_accountable[]">
                                    </div>
                                    <div class="col-md-1">
                                        <label>&nbsp;</label>
                                        <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-info" id="add_support_entry">
                            <i class="bi bi-plus-circle"></i> Add Support Function
                        </button>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between mt-4">
                    <button type="submit" name="save_dpcr" class="btn btn-primary me-2">Save as Draft</button>
                    <button type="submit" name="save_dpcr" class="btn btn-success" onclick="document.getElementById('submit_now').value = '1'">Submit DPCR</button>
                    <input type="hidden" id="submit_now" name="submit_now" value="0">
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Show/hide support functions based on computation type
    $('#computation_type').on('change', function() {
        updateComputationTypeDisplay();
    });
    
    // Initialize display
    updateComputationTypeDisplay();
    
    function updateComputationTypeDisplay() {
        var computationType = $('#computation_type').val();
        if (computationType === 'Type2') {
            $('#support_functions_container').show();
            $('#core_weight').text('(45%)');
        } else {
            $('#support_functions_container').hide();
            $('#core_weight').text('(55%)');
        }
    }
    
    // Add strategic entry
    $('#add_strategic_entry').click(function() {
        var newEntry = `
            <div class="row mb-3 strategic-entry">
                <div class="col-md-4">
                    <label>Major Final Output</label>
                    <textarea class="form-control" name="strategic_major_output[]" rows="3" required></textarea>
                </div>
                <div class="col-md-3">
                    <label>Success Indicators</label>
                    <textarea class="form-control" name="strategic_success_indicators[]" rows="3" required></textarea>
                </div>
                <div class="col-md-2">
                    <label>Budget</label>
                    <input type="number" class="form-control" name="strategic_budget[]" step="0.01" min="0">
                </div>
                <div class="col-md-2">
                    <label>Accountable Person/Office</label>
                    <input type="text" class="form-control" name="strategic_accountable[]">
                </div>
                <div class="col-md-1">
                    <label>&nbsp;</label>
                    <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                </div>
            </div>
        `;
        $('#strategic_functions').append(newEntry);
    });
    
    // Add core entry
    $('#add_core_entry').click(function() {
        var newEntry = `
            <div class="row mb-3 core-entry">
                <div class="col-md-4">
                    <label>Major Final Output</label>
                    <textarea class="form-control" name="core_major_output[]" rows="3" required></textarea>
                </div>
                <div class="col-md-3">
                    <label>Success Indicators</label>
                    <textarea class="form-control" name="core_success_indicators[]" rows="3" required></textarea>
                </div>
                <div class="col-md-2">
                    <label>Budget</label>
                    <input type="number" class="form-control" name="core_budget[]" step="0.01" min="0">
                </div>
                <div class="col-md-2">
                    <label>Accountable Person/Office</label>
                    <input type="text" class="form-control" name="core_accountable[]">
                </div>
                <div class="col-md-1">
                    <label>&nbsp;</label>
                    <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                </div>
            </div>
        `;
        $('#core_functions').append(newEntry);
    });
    
    // Add support entry
    $('#add_support_entry').click(function() {
        var newEntry = `
            <div class="row mb-3 support-entry">
                <div class="col-md-4">
                    <label>Major Final Output</label>
                    <textarea class="form-control" name="support_major_output[]" rows="3"></textarea>
                </div>
                <div class="col-md-3">
                    <label>Success Indicators</label>
                    <textarea class="form-control" name="support_success_indicators[]" rows="3"></textarea>
                </div>
                <div class="col-md-2">
                    <label>Budget</label>
                    <input type="number" class="form-control" name="support_budget[]" step="0.01" min="0">
                </div>
                <div class="col-md-2">
                    <label>Accountable Person/Office</label>
                    <input type="text" class="form-control" name="support_accountable[]">
                </div>
                <div class="col-md-1">
                    <label>&nbsp;</label>
                    <button type="button" class="btn btn-danger btn-sm d-block w-100 remove-entry">Remove</button>
                </div>
            </div>
        `;
        $('#support_functions').append(newEntry);
    });
    
    // Remove entry
    $(document).on('click', '.remove-entry', function() {
        $(this).closest('.row').remove();
    });
});
</script>

<?php
// Close database connection
$conn->close();

// Include footer
include_once('includes/footer.php');
?> 