<?php
// Set page title
$page_title = "Individual Development Plan - EPMS";

// Include header
include_once('includes/header.php');

// Check if user has the right role to access this page
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'regular_employee' && $_SESSION['user_role'] !== 'department_head' && $_SESSION['user_role'] !== 'president' && $_SESSION['user_role'] !== 'admin')) {
    header("Location: access_denied.php");
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "epms_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$user_department_id = $_SESSION['user_department_id'];

// Get department name
$dept_query = "SELECT name FROM departments WHERE id = ?";
$stmt = $conn->prepare($dept_query);
$stmt->bind_param("i", $user_department_id);
$stmt->execute();
$dept_result = $stmt->get_result();
$department_name = ($dept_result->num_rows > 0) ? $dept_result->fetch_assoc()['name'] : 'Unknown Department';

// Get existing IDP records for current user
$records_query = "SELECT * FROM records WHERE user_id = ? AND form_type = 'IDP' ORDER BY date_submitted DESC";
$stmt = $conn->prepare($records_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$records_result = $stmt->get_result();

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_idp'])) {
    // Process form data
    $period = $_POST['period'];
    $content = $_POST['content'] ?? ''; // Form content as JSON
    
    // Insert new IDP record
    $insert_query = "INSERT INTO records (user_id, form_type, period, content, status) VALUES (?, 'IDP', ?, ?, 'Pending')";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("iss", $user_id, $period, $content);
    
    if ($stmt->execute()) {
        $success_message = "IDP form submitted successfully. It is now pending for review.";
    } else {
        $error_message = "Error submitting IDP form: " . $conn->error;
    }
}
?>

<!-- IDP Content -->
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Individual Development Plan</h1>
        <div>
            <button class="btn btn-sm btn-outline-secondary me-2">
                <i class="bi bi-calendar"></i> 
                <?php echo date('F d, Y'); ?>
            </button>
            <button class="btn btn-sm btn-primary">
                <i class="bi bi-printer"></i> Print Form
            </button>
        </div>
    </div>
    
    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header bg-white">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="#new-form" data-bs-toggle="tab">Create New IDP</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#history" data-bs-toggle="tab">IDP History</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="new-form">
                    <form action="idp.php" method="POST" id="idp-form">
                        <div class="mb-3">
                            <label for="period" class="form-label">Development Period</label>
                            <select class="form-select" name="period" id="period" required>
                                <option value="">Select Period</option>
                                <option value="Annual <?php echo date('Y'); ?>">Annual <?php echo date('Y'); ?></option>
                                <option value="Annual <?php echo date('Y')+1; ?>">Annual <?php echo date('Y')+1; ?></option>
                            </select>
                        </div>
                        
                        <h5 class="text-center fw-bold my-4">INDIVIDUAL DEVELOPMENT PLAN (IDP) FORM</h5>
                        
                        <div class="mb-4">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Department:</strong> <?php echo htmlspecialchars($department_name); ?></p>
                                </div>
                            </div>
                            <p>This form outlines my personal development goals and action plan for the period <span id="period-display"></span>.</p>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered mb-4">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 25%">Development Goals</th>
                                        <th style="width: 25%">Required Competencies</th>
                                        <th style="width: 25%">Action Plan / Learning Activities</th>
                                        <th style="width: 15%">Timeline</th>
                                        <th style="width: 10%">Status</th>
                                    </tr>
                                </thead>
                                <tbody id="idp-table-body">
                                    <tr>
                                        <td colspan="5" class="text-center bg-light fw-bold">PROFESSIONAL DEVELOPMENT</td>
                                    </tr>
                                    <?php for($i = 0; $i < 2; $i++): ?>
                                    <tr class="professional-dev-row">
                                        <td>
                                            <textarea class="form-control form-control-sm" name="prof_goals[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="prof_competencies[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="prof_actions[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control form-control-sm" name="prof_timeline[]" placeholder="e.g., Q1 2024">
                                        </td>
                                        <td>
                                            <select class="form-select form-select-sm" name="prof_status[]">
                                                <option value="Not Started">Not Started</option>
                                                <option value="In Progress">In Progress</option>
                                                <option value="Completed">Completed</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                    
                                    <tr>
                                        <td colspan="5" class="text-center bg-light fw-bold">PERSONAL DEVELOPMENT</td>
                                    </tr>
                                    <?php for($i = 0; $i < 1; $i++): ?>
                                    <tr class="personal-dev-row">
                                        <td>
                                            <textarea class="form-control form-control-sm" name="pers_goals[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="pers_competencies[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="pers_actions[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control form-control-sm" name="pers_timeline[]" placeholder="e.g., Q2 2024">
                                        </td>
                                        <td>
                                            <select class="form-select form-select-sm" name="pers_status[]">
                                                <option value="Not Started">Not Started</option>
                                                <option value="In Progress">In Progress</option>
                                                <option value="Completed">Completed</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                    
                                    <tr>
                                        <td colspan="5" class="text-center bg-light fw-bold">CAREER ADVANCEMENT</td>
                                    </tr>
                                    <?php for($i = 0; $i < 1; $i++): ?>
                                    <tr class="career-dev-row">
                                        <td>
                                            <textarea class="form-control form-control-sm" name="career_goals[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="career_competencies[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <textarea class="form-control form-control-sm" name="career_actions[]" rows="3"></textarea>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control form-control-sm" name="career_timeline[]" placeholder="e.g., End of 2024">
                                        </td>
                                        <td>
                                            <select class="form-select form-select-sm" name="career_status[]">
                                                <option value="Not Started">Not Started</option>
                                                <option value="In Progress">In Progress</option>
                                                <option value="Completed">Completed</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <button type="button" id="add-prof-row" class="btn btn-outline-primary btn-sm">
                                    <i class="bi bi-plus-circle"></i> Add Professional Development Goal
                                </button>
                                <button type="button" id="add-pers-row" class="btn btn-outline-primary btn-sm ms-2">
                                    <i class="bi bi-plus-circle"></i> Add Personal Development Goal
                                </button>
                                <button type="button" id="add-career-row" class="btn btn-outline-primary btn-sm ms-2">
                                    <i class="bi bi-plus-circle"></i> Add Career Goal
                                </button>
                            </div>
                            <div class="col-md-6 text-end">
                                <div class="d-flex justify-content-between mt-4">
                                    <button type="submit" name="save_idp" class="btn btn-secondary">
                                        <i class="bi bi-save"></i> Save as Draft
                                    </button>
                                    <div>
                                        <button type="submit" name="submit_idp" class="btn btn-primary">
                                            <i class="bi bi-check-circle"></i> Submit for Approval
                                        </button>
                                        <button type="button" class="btn btn-success ms-2" id="export-pdf">
                                            <i class="bi bi-file-earmark-pdf"></i> Export as PDF
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="resources_needed" class="form-label">Additional Resources Needed</label>
                            <textarea class="form-control" id="resources_needed" name="resources_needed" rows="3" placeholder="List any resources, support, or funding required to achieve your development goals."></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="notes" class="form-label">Additional Notes</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Any additional information or context relevant to your development plan."></textarea>
                        </div>
                        
                        <!-- Hidden field for form data JSON -->
                        <input type="hidden" name="content" id="form-content-json">
                    </form>
                    
                    <div class="card mt-4">
                        <div class="card-header bg-light">
                            <h6 class="mb-0">About Individual Development Plan (IDP)</h6>
                        </div>
                        <div class="card-body">
                            <p class="mb-1"><strong>What is an IDP?</strong></p>
                            <p>An Individual Development Plan (IDP) is a tool to assist employees in career and personal development. Its primary purpose is to help employees reach short and long-term career goals, as well as improve current job performance.</p>
                            
                            <p class="mb-1 mt-3"><strong>Approval Process:</strong></p>
                            <ol class="small">
                                <li>Create and submit your IDP using this form</li>
                                <li>Your department head will review your IDP</li>
                                <li>Once approved, you can begin implementing your development plan</li>
                                <li>Periodically update your progress in the system</li>
                            </ol>
                            
                            <div class="alert alert-info small mt-3 mb-0">
                                <strong>Note:</strong> Your IDP should align with both your career goals and organizational objectives. Focus on development areas that will enhance your effectiveness in your current role while preparing you for future responsibilities.
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="tab-pane fade" id="history">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Period</th>
                                    <th>Submission Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($records_result->num_rows > 0): ?>
                                    <?php while ($record = $records_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($record['period']); ?></td>
                                            <td>
                                                <?php 
                                                if ($record['date_submitted']) {
                                                    echo date('M d, Y h:i A', strtotime($record['date_submitted']));
                                                } else {
                                                    echo '<span class="text-muted">Not submitted</span>';
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                $status_class = '';
                                                switch ($record['status']) {
                                                    case 'Draft':
                                                        $status_class = 'bg-secondary text-white';
                                                        break;
                                                    case 'Pending':
                                                        $status_class = 'bg-warning';
                                                        break;
                                                    case 'Approved':
                                                        $status_class = 'bg-success text-white';
                                                        break;
                                                    case 'Rejected':
                                                        $status_class = 'bg-danger text-white';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge <?php echo $status_class; ?>"><?php echo $record['status']; ?></span>
                                            </td>
                                            <td>
                                                <a href="view_record.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                                <?php if ($record['status'] === 'Draft'): ?>
                                                <a href="edit_idp.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                                    <i class="bi bi-pencil"></i> Edit
                                                </a>
                                                <?php endif; ?>
                                                <a href="print_record.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-dark">
                                                    <i class="bi bi-printer"></i> Print
                                                </a>
                                                <a href="javascript:void(0);" class="btn btn-sm btn-outline-success export-pdf-btn" data-id="<?php echo $record['id']; ?>">
                                                    <i class="bi bi-file-earmark-pdf"></i> PDF
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No IDP records found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include HTML2PDF library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Update the displayed period when select changes
    document.getElementById('period').addEventListener('change', function() {
        document.getElementById('period-display').textContent = this.value;
    });
    
    // Export to PDF functionality
    document.getElementById('export-pdf').addEventListener('click', function() {
        // Get the form content
        const formData = collectFormData();
        
        // Create a stylized HTML version for PDF export
        const pdfContent = generatePDFContent(formData);
        
        // Generate the PDF
        generatePDF(pdfContent, 'Individual_Development_Plan_' + formData.period.replace(/\s+/g, '_'));
    });
    
    // Export existing record to PDF
    document.querySelectorAll('.export-pdf-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const recordId = this.getAttribute('data-id');
            window.location.href = 'export_pdf.php?id=' + recordId + '&type=IDP';
        });
    });
    
    // Collect form data for submission or PDF generation
    function collectFormData() {
        const formData = {
            period: document.getElementById('period').value,
            professional_development: [],
            personal_development: []
        };
        
        // Collect professional development items
        document.querySelectorAll('.professional-dev-row').forEach(function(row) {
            const goals = row.querySelector('[name="prof_goals[]"]').value;
            if (goals.trim()) {
                formData.professional_development.push({
                    goals: goals,
                    competencies: row.querySelector('[name="prof_competencies[]"]').value,
                    actions: row.querySelector('[name="prof_actions[]"]').value,
                    timeline: row.querySelector('[name="prof_timeline[]"]').value,
                    status: row.querySelector('[name="prof_status[]"]').value
                });
            }
        });
        
        // Collect personal development items
        document.querySelectorAll('.personal-dev-row').forEach(function(row) {
            const goals = row.querySelector('[name="pers_goals[]"]').value;
            if (goals.trim()) {
                formData.personal_development.push({
                    goals: goals,
                    competencies: row.querySelector('[name="pers_competencies[]"]').value,
                    actions: row.querySelector('[name="pers_actions[]"]').value,
                    timeline: row.querySelector('[name="pers_timeline[]"]').value,
                    status: row.querySelector('[name="pers_status[]"]').value
                });
            }
        });
        
        return formData;
    }
    
    // Generate styled HTML content for PDF export
    function generatePDFContent(data) {
        const userName = "<?php echo htmlspecialchars($_SESSION['user_name']); ?>";
        const departmentName = "<?php echo htmlspecialchars($department_name); ?>";
        
        let html = `
            <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 20px;">
                    <h2 style="margin-bottom: 5px;">Individual Development Plan (IDP)</h2>
                    <h3 style="margin-top: 5px; color: #555;">City College of Angeles</h3>
                    <p><strong>Period:</strong> ${data.period}</p>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <p><strong>Name:</strong> ${userName}</p>
                    <p><strong>Department:</strong> ${departmentName}</p>
                </div>
                
                <div style="margin-bottom: 30px;">
                    <h4 style="background-color: #f0f0f0; padding: 8px; border-bottom: 1px solid #ddd;">Professional Development</h4>
                    <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
                        <thead>
                            <tr style="background-color: #f8f9fa;">
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Development Goals</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Required Competencies</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Action Plan</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Timeline</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Status</th>
                            </tr>
                        </thead>
                        <tbody>`;
        
        if (data.professional_development.length > 0) {
            data.professional_development.forEach(item => {
                html += `
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.goals}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.competencies}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.actions}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.timeline}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.status}</td>
                    </tr>`;
            });
        } else {
            html += `<tr><td colspan="5" style="border: 1px solid #ddd; padding: 8px; text-align: center;">No professional development goals defined</td></tr>`;
        }
        
        html += `
                        </tbody>
                    </table>
                    
                    <h4 style="background-color: #f0f0f0; padding: 8px; border-bottom: 1px solid #ddd;">Personal Development</h4>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background-color: #f8f9fa;">
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Development Goals</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Required Competencies</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Action Plan</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Timeline</th>
                                <th style="border: 1px solid #ddd; padding: 8px; text-align: left;">Status</th>
                            </tr>
                        </thead>
                        <tbody>`;
        
        if (data.personal_development.length > 0) {
            data.personal_development.forEach(item => {
                html += `
                    <tr>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.goals}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.competencies}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.actions}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.timeline}</td>
                        <td style="border: 1px solid #ddd; padding: 8px;">${item.status}</td>
                    </tr>`;
            });
        } else {
            html += `<tr><td colspan="5" style="border: 1px solid #ddd; padding: 8px; text-align: center;">No personal development goals defined</td></tr>`;
        }
        
        html += `
                        </tbody>
                    </table>
                </div>
                
                <div style="margin-top: 40px;">
                    <div style="float: left; width: 45%;">
                        <p style="margin-bottom: 40px;">Employee Signature:</p>
                        <p>____________________________</p>
                        <p>Date: _____________________</p>
                    </div>
                    <div style="float: right; width: 45%;">
                        <p style="margin-bottom: 40px;">Department Head Signature:</p>
                        <p>____________________________</p>
                        <p>Date: _____________________</p>
                    </div>
                    <div style="clear: both;"></div>
                </div>
                
                <div style="margin-top: 20px; text-align: center; color: #777; font-size: 12px;">
                    <p>City College of Angeles - Employee Performance Management System</p>
                </div>
            </div>`;
            
        return html;
    }
    
    // Function to generate PDF from HTML content
    function generatePDF(htmlContent, fileName) {
        const element = document.createElement('div');
        element.innerHTML = htmlContent;
        document.body.appendChild(element);
        
        const opt = {
            margin: [10, 10, 10, 10],
            filename: fileName + '.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        
        html2pdf().set(opt).from(element).save().then(() => {
            document.body.removeChild(element);
        });
    }
    
    // Store form data as JSON before submission
    document.getElementById('idp-form').addEventListener('submit', function(e) {
        const formData = collectFormData();
        document.getElementById('form-content-json').value = JSON.stringify(formData);
    });
    
    // Add additional row for professional development
    document.querySelector('.professional-dev-row').insertAdjacentHTML('afterend', `
        <tr>
            <td colspan="5" class="text-end p-2">
                <button type="button" class="btn btn-sm btn-outline-primary" id="add-prof-row">
                    <i class="bi bi-plus-circle"></i> Add Professional Development Goal
                </button>
            </td>
        </tr>
    `);
    
    document.getElementById('add-prof-row').addEventListener('click', function() {
        const newRow = document.createElement('tr');
        newRow.className = 'professional-dev-row';
        newRow.innerHTML = `
            <td>
                <textarea class="form-control form-control-sm" name="prof_goals[]" rows="3"></textarea>
            </td>
            <td>
                <textarea class="form-control form-control-sm" name="prof_competencies[]" rows="3"></textarea>
            </td>
            <td>
                <textarea class="form-control form-control-sm" name="prof_actions[]" rows="3"></textarea>
            </td>
            <td>
                <input type="text" class="form-control form-control-sm" name="prof_timeline[]" placeholder="e.g., Q1 2024">
            </td>
            <td>
                <select class="form-select form-select-sm" name="prof_status[]">
                    <option value="Not Started">Not Started</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                </select>
            </td>
        `;
        
        // Insert before the "Add Row" row
        const addRowRow = document.getElementById('add-prof-row').closest('tr');
        addRowRow.parentNode.insertBefore(newRow, addRowRow);
    });
});
</script>

<?php
// Close database connection
$conn->close();

// Include footer
include_once('includes/footer.php');
?> 