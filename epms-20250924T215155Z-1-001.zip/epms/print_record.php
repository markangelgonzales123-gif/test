<?php
// Include session management
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Check if record ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: records.php");
    exit();
}

$record_id = intval($_GET['id']);

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "epms_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user info
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$department_id = $_SESSION['user_department_id'] ?? null;

// Get record data
$record_query = "SELECT r.*, u.name as employee_name, u.department_id, 
                 d.name as department_name, rev.name as reviewer_name
                 FROM records r 
                 JOIN users u ON r.user_id = u.id 
                 LEFT JOIN departments d ON u.department_id = d.id
                 LEFT JOIN users rev ON r.reviewed_by = rev.id
                 WHERE r.id = ?";
$stmt = $conn->prepare($record_query);
$stmt->bind_param("i", $record_id);
$stmt->execute();
$record_result = $stmt->get_result();

if ($record_result->num_rows === 0) {
    die("Record not found!");
}

$record = $record_result->fetch_assoc();

// Check permission to view this record
$has_permission = false;

// The record owner can always view
if ($record['user_id'] == $user_id) {
    $has_permission = true;
}
// Department head can view records from their department
else if ($user_role == 'department_head' && $record['department_id'] == $department_id) {
    $has_permission = true;
}
// Admin and president can view all records
else if ($user_role == 'admin' || $user_role == 'president') {
    $has_permission = true;
}

if (!$has_permission) {
    die("You don't have permission to view this record!");
}

// Get entries based on form type
$entries = [];

if ($record['form_type'] === 'DPCR') {
    $entries_query = "SELECT * FROM dpcr_entries WHERE record_id = ? ORDER BY category, id";
    $stmt = $conn->prepare($entries_query);
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $entries_result = $stmt->get_result();
    
    $strategic_entries = [];
    $core_entries = [];
    
    while ($entry = $entries_result->fetch_assoc()) {
        if ($entry['category'] === 'Strategic') {
            $strategic_entries[] = $entry;
        } else if ($entry['category'] === 'Core') {
            $core_entries[] = $entry;
        }
    }
    
    $entries = [
        'strategic' => $strategic_entries,
        'core' => $core_entries
    ];
} else if ($record['form_type'] === 'IPCR') {
    $entries_query = "SELECT * FROM ipcr_entries WHERE record_id = ? ORDER BY category, id";
    $stmt = $conn->prepare($entries_query);
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $entries_result = $stmt->get_result();
    
    $strategic_entries = [];
    $core_entries = [];
    $support_entries = [];
    
    while ($entry = $entries_result->fetch_assoc()) {
        if ($entry['category'] === 'Strategic') {
            $strategic_entries[] = $entry;
        } else if ($entry['category'] === 'Core') {
            $core_entries[] = $entry;
        } else if ($entry['category'] === 'Support') {
            $support_entries[] = $entry;
        }
    }
    
    $entries = [
        'strategic' => $strategic_entries,
        'core' => $core_entries,
        'support' => $support_entries
    ];
} else if ($record['form_type'] === 'IDP') {
    $entries_query = "SELECT * FROM idp_entries WHERE record_id = ? ORDER BY id";
    $stmt = $conn->prepare($entries_query);
    $stmt->bind_param("i", $record_id);
    $stmt->execute();
    $entries_result = $stmt->get_result();
    
    $idp_entries = [];
    
    while ($entry = $entries_result->fetch_assoc()) {
        $idp_entries[] = $entry;
    }
    
    $entries = [
        'idp' => $idp_entries
    ];
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print <?php echo $record['form_type']; ?> - <?php echo htmlspecialchars($record['employee_name']); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }
        .print-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .print-header img {
            max-width: 80px;
            height: auto;
        }
        .record-info {
            margin-bottom: 20px;
        }
        .record-info table {
            width: 100%;
            border-collapse: collapse;
        }
        .record-info td {
            padding: 5px 10px;
        }
        .record-info .label {
            font-weight: bold;
            width: 150px;
        }
        .section-title {
            background-color: #f0f0f0;
            padding: 10px;
            margin-top: 20px;
            margin-bottom: 10px;
            font-weight: bold;
        }
        table.data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        table.data-table th,
        table.data-table td {
            border: 1px solid #ddd;
            padding: 8px;
            vertical-align: top;
        }
        table.data-table th {
            background-color: #f5f5f5;
            font-weight: bold;
            text-align: left;
        }
        .signatures {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }
        .signature-block {
            width: 45%;
        }
        .signature-line {
            border-top: 1px solid #000;
            margin-top: 50px;
            padding-top: 5px;
            text-align: center;
        }
        .footnote {
            margin-top: 50px;
            font-size: 0.8em;
            text-align: center;
        }
        
        /* Print-specific CSS */
        @media print {
            body {
                padding: 0;
                margin: 0.5in;
                background-color: #fff;
            }
            
            .no-print, 
            .sidebar, 
            .main-content > *:not(#print-container) {
                display: none !important;
            }
            
            #print-container {
                display: block !important;
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
            }
            
            .print-header, 
            .record-info, 
            .section-title, 
            .data-table, 
            .signatures, 
            .footnote {
                page-break-inside: avoid;
            }
            
            @page {
                size: letter;
                margin: 0.5in;
            }
        }
        
        /* Controls visibility on screen vs print */
        .print-only {
            display: none;
        }
        
        @media print {
            .print-only {
                display: block;
            }
            
            .screen-only {
                display: none;
            }
        }
    </style>
    
    <!-- Additional stylesheet for print media only -->
    <style media="print">
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
        
        /* Hide everything except our print container */
        body > *:not(#print-container) {
            display: none !important;
        }
        
        #print-container {
            display: block !important;
            width: 100%;
            padding: 0;
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Screen-only controls -->
    <div class="screen-only no-print mb-3">
        <button class="btn btn-primary" onclick="window.print()">Print</button>
        <a href="view_record.php?id=<?php echo $record_id; ?>" class="btn btn-secondary">Back</a>
    </div>
    
    <!-- Print container that will be the only thing visible when printing -->
    <div id="print-container">
        <div class="print-header">
            <img src="images/CCA.jpg" alt="City College of Angeles Logo">
            <h4>CITY COLLEGE OF ANGELES</h4>
            <h5>Employee Performance Management System</h5>
            <h3><?php echo $record['form_type']; ?></h3>
        </div>
        
        <div class="record-info">
            <table>
                <tr>
                    <td class="label">Employee:</td>
                    <td><?php echo htmlspecialchars($record['employee_name']); ?></td>
                </tr>
                <tr>
                    <td class="label">Department:</td>
                    <td><?php echo htmlspecialchars($record['department_name'] ?? 'Not Assigned'); ?></td>
                </tr>
                <tr>
                    <td class="label">Period:</td>
                    <td><?php echo htmlspecialchars($record['period']); ?></td>
                </tr>
                <tr>
                    <td class="label">Status:</td>
                    <td><?php echo $record['status']; ?></td>
                </tr>
                <?php if ($record['date_submitted']): ?>
                <tr>
                    <td class="label">Date Submitted:</td>
                    <td><?php echo date('F d, Y', strtotime($record['date_submitted'])); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($record['reviewed_by']): ?>
                <tr>
                    <td class="label">Reviewed By:</td>
                    <td><?php echo htmlspecialchars($record['reviewer_name']); ?></td>
                </tr>
                <tr>
                    <td class="label">Date Reviewed:</td>
                    <td><?php echo date('F d, Y', strtotime($record['date_reviewed'])); ?></td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
        
        <?php if (!empty($record['comments'])): ?>
        <div class="comments mb-4">
            <div class="section-title">Comments/Feedback</div>
            <p><?php echo nl2br(htmlspecialchars($record['comments'])); ?></p>
        </div>
        <?php endif; ?>
        
        <!-- DPCR Form Content -->
        <?php if ($record['form_type'] === 'DPCR'): ?>
            <div class="section-title">Strategic Functions (45%)</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="30%">Major Final Output</th>
                        <th width="30%">Success Indicators</th>
                        <th width="15%">Budget</th>
                        <th width="25%">Accountable Units</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries['strategic'])): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">No strategic outputs defined</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($entries['strategic'] as $entry): ?>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($entry['major_output'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                            <td><?php echo htmlspecialchars($entry['budget'] ? number_format($entry['budget'], 2) : 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($entry['accountable']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div class="section-title">Core Functions (55%)</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="30%">Major Final Output</th>
                        <th width="30%">Success Indicators</th>
                        <th width="15%">Budget</th>
                        <th width="25%">Accountable Units</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries['core'])): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">No core outputs defined</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($entries['core'] as $entry): ?>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($entry['major_output'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                            <td><?php echo htmlspecialchars($entry['budget'] ? number_format($entry['budget'], 2) : 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($entry['accountable']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <!-- IPCR Form Content -->
        <?php if ($record['form_type'] === 'IPCR'): ?>
            <div class="section-title">Strategic Functions (45%)</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="20%">Major Final Output</th>
                        <th width="20%">Success Indicators</th>
                        <th width="30%">Actual Accomplishments</th>
                        <th width="20%" style="text-align: center;">Rating</th>
                        <th width="10%">Remarks</th>
                    </tr>
                    <tr>
                        <th colspan="3"></th>
                        <th style="text-align: center;">
                            <div style="display: flex; justify-content: space-between;">
                                <span style="width: 33%;">Q</span>
                                <span style="width: 33%;">E</span>
                                <span style="width: 33%;">T</span>
                            </div>
                        </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries['strategic'])): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">No strategic outputs defined</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($entries['strategic'] as $entry): ?>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($entry['major_output'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['actual_accomplishments'] ?? 'Not yet accomplished')); ?></td>
                            <td>
                                <div style="display: flex; justify-content: space-between; text-align: center;">
                                    <span style="width: 33%;"><?php echo $entry['q_rating'] ?? '-'; ?></span>
                                    <span style="width: 33%;"><?php echo $entry['e_rating'] ?? '-'; ?></span>
                                    <span style="width: 33%;"><?php echo $entry['t_rating'] ?? '-'; ?></span>
                                </div>
                                <?php if (isset($entry['final_rating'])): ?>
                                <div style="text-align: center; margin-top: 10px; font-weight: bold;">
                                    Final: <?php echo $entry['final_rating']; ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($entry['remarks'] ?? ''); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <div class="section-title">Core Functions (45%)</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="20%">Major Final Output</th>
                        <th width="20%">Success Indicators</th>
                        <th width="30%">Actual Accomplishments</th>
                        <th width="20%" style="text-align: center;">Rating</th>
                        <th width="10%">Remarks</th>
                    </tr>
                    <tr>
                        <th colspan="3"></th>
                        <th style="text-align: center;">
                            <div style="display: flex; justify-content: space-between;">
                                <span style="width: 33%;">Q</span>
                                <span style="width: 33%;">E</span>
                                <span style="width: 33%;">T</span>
                            </div>
                        </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries['core'])): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">No core outputs defined</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($entries['core'] as $entry): ?>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($entry['major_output'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['actual_accomplishments'] ?? 'Not yet accomplished')); ?></td>
                            <td>
                                <div style="display: flex; justify-content: space-between; text-align: center;">
                                    <span style="width: 33%;"><?php echo $entry['q_rating'] ?? '-'; ?></span>
                                    <span style="width: 33%;"><?php echo $entry['e_rating'] ?? '-'; ?></span>
                                    <span style="width: 33%;"><?php echo $entry['t_rating'] ?? '-'; ?></span>
                                </div>
                                <?php if (isset($entry['final_rating'])): ?>
                                <div style="text-align: center; margin-top: 10px; font-weight: bold;">
                                    Final: <?php echo $entry['final_rating']; ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($entry['remarks'] ?? ''); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if (!empty($entries['support'])): ?>
            <div class="section-title">Support Functions (10%)</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="20%">Major Final Output</th>
                        <th width="20%">Success Indicators</th>
                        <th width="30%">Actual Accomplishments</th>
                        <th width="20%" style="text-align: center;">Rating</th>
                        <th width="10%">Remarks</th>
                    </tr>
                    <tr>
                        <th colspan="3"></th>
                        <th style="text-align: center;">
                            <div style="display: flex; justify-content: space-between;">
                                <span style="width: 33%;">Q</span>
                                <span style="width: 33%;">E</span>
                                <span style="width: 33%;">T</span>
                            </div>
                        </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($entries['support'] as $entry): ?>
                    <tr>
                        <td><?php echo nl2br(htmlspecialchars($entry['major_output'])); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($entry['actual_accomplishments'] ?? 'Not yet accomplished')); ?></td>
                        <td>
                            <div style="display: flex; justify-content: space-between; text-align: center;">
                                <span style="width: 33%;"><?php echo $entry['q_rating'] ?? '-'; ?></span>
                                <span style="width: 33%;"><?php echo $entry['e_rating'] ?? '-'; ?></span>
                                <span style="width: 33%;"><?php echo $entry['t_rating'] ?? '-'; ?></span>
                            </div>
                            <?php if (isset($entry['final_rating'])): ?>
                            <div style="text-align: center; margin-top: 10px; font-weight: bold;">
                                Final: <?php echo $entry['final_rating']; ?>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($entry['remarks'] ?? ''); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        <?php endif; ?>
        
        <!-- IDP Form Content -->
        <?php if ($record['form_type'] === 'IDP'): ?>
            <div class="section-title">Individual Development Plan</div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th width="15%">Development Needs</th>
                        <th width="20%">Development Interventions</th>
                        <th width="10%">Target Competency Level</th>
                        <th width="20%">Success Indicators</th>
                        <th width="15%">Timeline</th>
                        <th width="10%">Resources Needed</th>
                        <th width="10%">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($entries['idp'])): ?>
                    <tr>
                        <td colspan="7" style="text-align: center;">No development plans defined</td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($entries['idp'] as $entry): ?>
                        <tr>
                            <td><?php echo nl2br(htmlspecialchars($entry['development_needs'])); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['development_interventions'])); ?></td>
                            <td style="text-align: center;"><?php echo htmlspecialchars($entry['target_competency_level']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($entry['success_indicators'])); ?></td>
                            <td>
                                <?php if ($entry['timeline_start'] && $entry['timeline_end']): ?>
                                    <?php echo date('M d, Y', strtotime($entry['timeline_start'])); ?> to 
                                    <?php echo date('M d, Y', strtotime($entry['timeline_end'])); ?>
                                <?php else: ?>
                                    Not specified
                                <?php endif; ?>
                            </td>
                            <td><?php echo nl2br(htmlspecialchars($entry['resources_needed'] ?? 'None')); ?></td>
                            <td><?php echo $entry['status']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
        <div class="signatures">
            <div class="signature-block">
                <div class="signature-line">
                    <?php echo htmlspecialchars($record['employee_name']); ?><br>
                    <small>Employee</small>
                </div>
            </div>
            
            <div class="signature-block">
                <div class="signature-line">
                    <?php echo htmlspecialchars($record['reviewer_name'] ?? '____________________'); ?><br>
                    <small>Reviewer</small>
                </div>
            </div>
        </div>
        
        <div class="footnote">
            <p>This document is generated by the City College of Angeles Employee Performance Management System.</p>
            <p>Printed on <?php echo date('F d, Y'); ?></p>
        </div>
    </div>
    
    <script>
        // Automatically focus the print container when page loads
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('print-container').focus();
        });
    </script>
</body>
</html> 