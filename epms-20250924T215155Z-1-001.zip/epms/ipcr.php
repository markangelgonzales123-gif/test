<?php
// Set page title
$page_title = "Individual Performance Commitment and Review - EPMS";

// Include header
include_once('includes/header.php');

// Include form workflow functions
include_once('includes/form_workflow.php');

// Check if user has the right role to access this page
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'regular_employee' && $_SESSION['user_role'] !== 'department_head' && $_SESSION['user_role'] !== 'president' && $_SESSION['user_role'] !== 'admin')) {
    header("Location: access_denied.php");
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "epms_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];
$user_department_id = $_SESSION['user_department_id'];

// Get department name
$dept_query = "SELECT name FROM departments WHERE id = ?";
$stmt = $conn->prepare($dept_query);
$stmt->bind_param("i", $user_department_id);
$stmt->execute();
$dept_result = $stmt->get_result();
$department_name = ($dept_result->num_rows > 0) ? $dept_result->fetch_assoc()['name'] : 'Unknown Department';

// Get existing IPCR records for current user
$records_query = "SELECT * FROM records WHERE user_id = ? AND form_type = 'IPCR' ORDER BY date_submitted DESC";
$stmt = $conn->prepare($records_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$records_result = $stmt->get_result();

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form data
    $period = $_POST['period'];
    $content = $_POST['content'] ?? ''; // Form content as JSON
    
    // Check if it's a save draft or submit operation
    if (isset($_POST['save_draft'])) {
        // Insert new IPCR record as Draft
        $insert_query = "INSERT INTO records (user_id, form_type, period, content, status) VALUES (?, 'IPCR', ?, ?, 'Draft')";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iss", $user_id, $period, $content);
        
        if ($stmt->execute()) {
            $success_message = "IPCR form saved as draft successfully.";
        } else {
            $error_message = "Error saving draft: " . $conn->error;
        }
    } else if (isset($_POST['submit_ipcr'])) {
        // Submit form for review using the workflow function
        $result = submitForm($conn, $user_id, 'IPCR', $period, $content);
        
        if ($result['success']) {
            // Get department head info for the confirmation message
            $dept_head_query = "SELECT u.name, u.email FROM users u 
                               WHERE u.department_id = ? AND u.role = 'department_head'";
            $dept_stmt = $conn->prepare($dept_head_query);
            $dept_stmt->bind_param("i", $user_department_id);
            $dept_stmt->execute();
            $dept_head_result = $dept_stmt->get_result();
            $dept_head = ($dept_head_result->num_rows > 0) ? $dept_head_result->fetch_assoc() : null;
            $dept_head_name = $dept_head ? $dept_head['name'] : "your department head";
            
            // Create a more visible success message with department head's name
            $success_message = "
                <div class='mb-3'><strong class='fs-5'>IPCR form submitted successfully!</strong></div>
                <div class='d-flex align-items-center mb-2'>
                    <div class='me-3'><i class='bi bi-check-circle-fill text-success fs-3'></i></div>
                    <div>
                        Your form has been sent to <strong>" . htmlspecialchars($dept_head_name) . "</strong> for review. 
                        You will be notified when your submission has been reviewed.
                    </div>
                </div>
                <div class='mt-2 small'>You can track the status of your submission in the <a href='#history' class='alert-link' data-bs-toggle='tab'>IPCR History tab</a>.</div>";
        } else {
            $error_message = $result['message'];
        }
    }
}
?>

<!-- IPCR Content -->
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Individual Performance Commitment and Review</h1>
        <div>
            <button class="btn btn-sm btn-outline-secondary me-2">
                <i class="bi bi-calendar"></i> 
                <?php echo date('F d, Y'); ?>
            </button>
            <button class="btn btn-sm btn-primary">
                <i class="bi bi-printer"></i> Print Form
            </button>
        </div>
    </div>
    
    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header bg-white">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link active" href="#new-form" data-bs-toggle="tab">Create New IPCR</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#history" data-bs-toggle="tab">IPCR History</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div class="tab-pane fade show active" id="new-form">
                    <form action="ipcr.php" method="POST" id="ipcr-form">
                        <div class="mb-3">
                            <label for="period" class="form-label">Evaluation Period</label>
                            <select class="form-select" name="period" id="period" required>
                                <option value="">Select Period</option>
                                <option value="Q1 <?php echo date('Y'); ?>">Q1 (January-March) <?php echo date('Y'); ?></option>
                                <option value="Q2 <?php echo date('Y'); ?>">Q2 (April-June) <?php echo date('Y'); ?></option>
                                <option value="Q3 <?php echo date('Y'); ?>">Q3 (July-September) <?php echo date('Y'); ?></option>
                                <option value="Q4 <?php echo date('Y'); ?>">Q4 (October-December) <?php echo date('Y'); ?></option>
                                <option value="Annual <?php echo date('Y'); ?>">Annual <?php echo date('Y'); ?></option>
                            </select>
                        </div>
                        
                        <h5 class="text-center fw-bold my-4">INDIVIDUAL PERFORMANCE COMMITMENT AND REVIEW (IPCR) FORM</h5>
                        
                        <div class="mb-4">
                            <p>I, <u><?php echo htmlspecialchars($_SESSION['user_name']); ?></u>, of <u><?php echo htmlspecialchars($department_name); ?></u>, 
                            commit to deliver and agree to be rated on the attainment of the following targets in accordance with the indicated measures for the period <span id="period-display"></span>.</p>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered mb-4">
                                <thead class="table-light">
                                    <tr>
                                        <th rowspan="2" class="align-middle text-center" style="width: 20%">MAJOR FINAL OUTPUT (MFO)</th>
                                        <th rowspan="2" class="align-middle text-center" style="width: 20%">SUCCESS INDICATORS (Targets + Measures)</th>
                                        <th rowspan="2" class="align-middle text-center" style="width: 15%">ACTUAL ACCOMPLISHMENTS</th>
                                        <th colspan="4" class="text-center">SELF-RATING</th>
                                        <th colspan="4" class="text-center">SUPERVISOR'S RATING</th>
                                        <th rowspan="2" class="align-middle text-center">REMARKS</th>
                                    </tr>
                                    <tr>
                                        <th class="text-center">Q</th>
                                        <th class="text-center">E</th>
                                        <th class="text-center">T</th>
                                        <th class="text-center">A</th>
                                        <th class="text-center">Q</th>
                                        <th class="text-center">E</th>
                                        <th class="text-center">T</th>
                                        <th class="text-center">A</th>
                                    </tr>
                                </thead>
                                <tbody id="ipcr-table-body">
                                    <tr>
                                        <td colspan="12" class="text-center bg-light fw-bold">STRATEGIC FUNCTIONS (45%)</td>
                                    </tr>
                                    <?php for($i = 0; $i < 3; $i++): ?>
                                    <tr class="strategic-function-row">
                                        <td><input type="text" class="form-control form-control-sm" name="strategic_mfo[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="strategic_success_indicators[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="strategic_accomplishments[]"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="strategic_q[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="strategic" data-rating="q"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="strategic_e[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="strategic" data-rating="e"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="strategic_t[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="strategic" data-rating="t"></td>
                                        <td><input type="text" class="form-control form-control-sm average-rating" name="strategic_a[]" readonly data-index="<?php echo $i; ?>"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="strategic_remarks[]"></td>
                                    </tr>
                                    <?php endfor; ?>
                                    
                                    <tr>
                                        <td colspan="12" class="text-center bg-light fw-bold">CORE FUNCTIONS (45%)</td>
                                    </tr>
                                    <?php for($i = 0; $i < 3; $i++): ?>
                                    <tr class="core-function-row">
                                        <td><input type="text" class="form-control form-control-sm" name="core_mfo[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="core_success_indicators[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="core_accomplishments[]"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="core_q[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="core" data-rating="q"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="core_e[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="core" data-rating="e"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="core_t[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="core" data-rating="t"></td>
                                        <td><input type="text" class="form-control form-control-sm average-rating" name="core_a[]" readonly data-index="<?php echo $i; ?>"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="core_remarks[]"></td>
                                    </tr>
                                    <?php endfor; ?>
                                    
                                    <tr>
                                        <td colspan="12" class="text-center bg-light fw-bold">SUPPORT FUNCTIONS (10%)</td>
                                    </tr>
                                    <?php for($i = 0; $i < 2; $i++): ?>
                                    <tr class="support-function-row">
                                        <td><input type="text" class="form-control form-control-sm" name="support_mfo[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="support_success_indicators[]"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="support_accomplishments[]"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="support_q[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="support" data-rating="q"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="support_e[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="support" data-rating="e"></td>
                                        <td><input type="number" class="form-control form-control-sm rating-input self-rating" name="support_t[]" min="1" max="5" data-index="<?php echo $i; ?>" data-type="support" data-rating="t"></td>
                                        <td><input type="text" class="form-control form-control-sm average-rating" name="support_a[]" readonly data-index="<?php echo $i; ?>"></td>
                                        <td><input type="text" class="form-control form-control-sm" name="support_remarks[]"></td>
                                    </tr>
                                    <?php endfor; ?>
                                    
                                    <!-- Summary section -->
                                    <tr>
                                        <td colspan="3" class="text-end fw-bold">Category Averages:</td>
                                        <td colspan="4">
                                            <div class="row">
                                                <div class="col-md-6">Strategic (45%):</div>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control form-control-sm" id="strategic_average" readonly>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <div class="col-md-6">Core (45%):</div>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control form-control-sm" id="core_average" readonly>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <div class="col-md-6">Support (10%):</div>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control form-control-sm" id="support_average" readonly>
                                                </div>
                                            </div>
                                        </td>
                                        <td colspan="4" class="align-middle">
                                            <div class="row">
                                                <div class="col-md-6 fw-bold">Final Rating:</div>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control form-control-sm" id="final_rating" name="final_rating" readonly>
                                                </div>
                                            </div>
                                            <div class="row mt-1">
                                                <div class="col-md-12 text-center" id="rating_interpretation"></div>
                                            </div>
                                        </td>
                                        <td colspan="1"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        
                        <div class="card mt-3 mb-3">
                            <div class="card-header bg-light">
                                <h6 class="mb-0">Rating Guide</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h6>Quality (Q)</h6>
                                        <ul class="small">
                                            <li><strong>5</strong> - Outstanding: Exceptional quality, exceeds expectations</li>
                                            <li><strong>4</strong> - Very Satisfactory: High quality, meets all expectations</li>
                                            <li><strong>3</strong> - Satisfactory: Acceptable quality, meets basic expectations</li>
                                            <li><strong>2</strong> - Unsatisfactory: Poor quality, below expectations</li>
                                            <li><strong>1</strong> - Poor: Very low quality, significantly below expectations</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Efficiency (E)</h6>
                                        <ul class="small">
                                            <li><strong>5</strong> - Outstanding: Excellent use of resources</li>
                                            <li><strong>4</strong> - Very Satisfactory: Good resource utilization</li>
                                            <li><strong>3</strong> - Satisfactory: Average resource utilization</li>
                                            <li><strong>2</strong> - Unsatisfactory: Poor resource utilization</li>
                                            <li><strong>1</strong> - Poor: Wasteful use of resources</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-4">
                                        <h6>Timeliness (T)</h6>
                                        <ul class="small">
                                            <li><strong>5</strong> - Outstanding: Much earlier than deadline</li>
                                            <li><strong>4</strong> - Very Satisfactory: Ahead of deadline</li>
                                            <li><strong>3</strong> - Satisfactory: On time</li>
                                            <li><strong>2</strong> - Unsatisfactory: Slightly late</li>
                                            <li><strong>1</strong> - Poor: Significantly late</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="alert alert-info small mt-2 mb-0">
                                    <strong>Note:</strong> The Average (A) rating is automatically calculated as the average of Q, E, and T ratings.
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-secondary" name="save_draft">
                                <i class="bi bi-save me-1"></i> Save as Draft
                            </button>
                            <button type="submit" class="btn btn-primary" name="submit_ipcr">
                                <i class="bi bi-check-circle me-1"></i> Submit for Review
                            </button>
                        </div>
                        
                        <!-- Hidden field to store the form content as JSON -->
                        <input type="hidden" name="content" id="form-content">
                    </form>
                </div>
                
                <div class="tab-pane fade" id="history">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Period</th>
                                    <th>Date Submitted</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($records_result->num_rows > 0): ?>
                                    <?php while ($record = $records_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($record['period']); ?></td>
                                            <td><?php echo ($record['date_submitted']) ? date('M d, Y', strtotime($record['date_submitted'])) : 'Not submitted'; ?></td>
                                            <td>
                                                <?php 
                                                $status_badge = 'secondary';
                                                switch ($record['status']) {
                                                    case 'Approved':
                                                        $status_badge = 'success';
                                                        break;
                                                    case 'Pending':
                                                        $status_badge = 'warning';
                                                        break;
                                                    case 'Rejected':
                                                        $status_badge = 'danger';
                                                        break;
                                                }
                                                ?>
                                                <span class="badge bg-<?php echo $status_badge; ?>">
                                                    <?php echo $record['status']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="view_record.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                                <?php if ($record['status'] == 'Draft' || $record['status'] == 'Rejected'): ?>
                                                    <a href="edit_record.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                                        <i class="bi bi-pencil"></i> Edit
                                                    </a>
                                                <?php endif; ?>
                                                <a href="print_record.php?id=<?php echo $record['id']; ?>" class="btn btn-sm btn-outline-info">
                                                    <i class="bi bi-printer"></i> Print
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center">No IPCR records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include the auto-scoring.js file -->
<script src="js/auto_scoring.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Update period display when period is selected
        const periodSelect = document.getElementById('period');
        const periodDisplay = document.getElementById('period-display');
        
        periodSelect.addEventListener('change', function() {
            periodDisplay.textContent = this.value;
        });
        
        // Prepare form data as JSON before submission
        document.getElementById('ipcr-form').addEventListener('submit', function(e) {
            const formData = {
                period: document.getElementById('period').value,
                strategic_functions: [],
                core_functions: [],
                support_functions: [],
                final_rating: document.getElementById('final_rating').value,
                strategic_average: document.getElementById('strategic_average').value,
                core_average: document.getElementById('core_average').value,
                support_average: document.getElementById('support_average').value,
                rating_interpretation: document.getElementById('rating_interpretation').textContent
            };
            
            // Collect strategic functions data
            document.querySelectorAll('.strategic-function-row').forEach(function(row, index) {
                const mfo = row.querySelector('input[name="strategic_mfo[]"]').value;
                if (mfo.trim() !== '') {
                    formData.strategic_functions.push({
                        mfo: mfo,
                        indicators: row.querySelector('input[name="strategic_success_indicators[]"]').value,
                        accomplishments: row.querySelector('input[name="strategic_accomplishments[]"]').value,
                        q: row.querySelector('input[name="strategic_q[]"]').value,
                        e: row.querySelector('input[name="strategic_e[]"]').value,
                        t: row.querySelector('input[name="strategic_t[]"]').value,
                        a: row.querySelector('input[name="strategic_a[]"]').value,
                        remarks: row.querySelector('input[name="strategic_remarks[]"]').value
                    });
                }
            });
            
            // Collect core functions data
            document.querySelectorAll('.core-function-row').forEach(function(row, index) {
                const mfo = row.querySelector('input[name="core_mfo[]"]').value;
                if (mfo.trim() !== '') {
                    formData.core_functions.push({
                        mfo: mfo,
                        indicators: row.querySelector('input[name="core_success_indicators[]"]').value,
                        accomplishments: row.querySelector('input[name="core_accomplishments[]"]').value,
                        q: row.querySelector('input[name="core_q[]"]').value,
                        e: row.querySelector('input[name="core_e[]"]').value,
                        t: row.querySelector('input[name="core_t[]"]').value,
                        a: row.querySelector('input[name="core_a[]"]').value,
                        remarks: row.querySelector('input[name="core_remarks[]"]').value
                    });
                }
            });
            
            // Collect support functions data
            document.querySelectorAll('.support-function-row').forEach(function(row, index) {
                const mfo = row.querySelector('input[name="support_mfo[]"]').value;
                if (mfo.trim() !== '') {
                    formData.support_functions.push({
                        mfo: mfo,
                        indicators: row.querySelector('input[name="support_success_indicators[]"]').value,
                        accomplishments: row.querySelector('input[name="support_accomplishments[]"]').value,
                        q: row.querySelector('input[name="support_q[]"]').value,
                        e: row.querySelector('input[name="support_e[]"]').value,
                        t: row.querySelector('input[name="support_t[]"]').value,
                        a: row.querySelector('input[name="support_a[]"]').value,
                        remarks: row.querySelector('input[name="support_remarks[]"]').value
                    });
                }
            });
            
            document.getElementById('form-content').value = JSON.stringify(formData);
        });
        
        // Check if we have a success message indicating a submission
        const successMessage = document.querySelector('.alert-success');
        if (successMessage && successMessage.textContent.includes('submitted successfully')) {
            // Add a delayed tab switch to history tab
            setTimeout(() => {
                document.querySelector('a[href="#history"]').click();
            }, 3000); // Switch after 3 seconds
        }
        
        // Add event listener to the link in the success message
        const historyTabLink = document.querySelector('.alert-success a[href="#history"]');
        if (historyTabLink) {
            historyTabLink.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector('a[href="#history"]').click();
            });
        }
    });
</script>

<?php
// Close database connection
$conn->close();

// Include footer
include_once('includes/footer.php');
?> 